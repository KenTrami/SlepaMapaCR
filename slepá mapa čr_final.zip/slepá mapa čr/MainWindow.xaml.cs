﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace slepá_mapa_čr
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private int skore;

        public int Skore
        {
            get => skore;
            set
            {
                skore = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(skore)));
            }
        }
        private int kolo;

        public int Kolo
        {
            get => kolo;
            set
            {
                kolo = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Kolo)));
            }
        }

        string aktualniMesto;
        List<MapPoint> points = new List<MapPoint>()
        {
            new MapPoint{Name= "Praha", XPercent = 0.38, YPercent = 0.38,IDMesta="Město1"},
            new MapPoint{Name= "Brno", XPercent=0.6938, YPercent=0.7105,IDMesta="Město2" },
            new MapPoint{Name= "Pardubice", XPercent=0.5614, YPercent=0.4, IDMesta="Město3" },
            new MapPoint{Name= "Ostrava", XPercent=0.9074, YPercent=0.4550, IDMesta="Město4" },
            new MapPoint{Name= "Plzeň", XPercent=0.1952, YPercent=0.5255, IDMesta="Město5" },
            new MapPoint{Name= "Liberec", XPercent=0.4388, YPercent=0.1314, IDMesta="Město6" },
            new MapPoint{Name= "Olomouc", XPercent=0.7820, YPercent=0.5426, IDMesta="Město7" },
            new MapPoint{Name= "České Budějovice", XPercent=0.3761, YPercent=0.8174, IDMesta="Město8" },
            new MapPoint{Name= "Hradec Králové", XPercent=0.5427, YPercent=0.3041, IDMesta="Město9" },
            new MapPoint{Name= "Ústí nad Labem", XPercent=0.3, YPercent=0.1528, IDMesta="Město10" },
            new MapPoint{Name= "Zlín", XPercent=0.8305, YPercent=0.6803, IDMesta="Město11" },
            new MapPoint{Name= "Karlovy Vary", XPercent=0.1197, YPercent=0.3139, IDMesta="Město12" },
            new MapPoint{Name= "Jihlava", XPercent=0.5342, YPercent=0.6423, IDMesta="Město13" }
        };
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            this.DataContext = this;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DrawPoints();
            nahoda();
        }
        public void nahoda()
        {
            Random rand = new Random();
            aktualniMesto = points[rand.Next(points.Count)].Name;
            Console.WriteLine($"Klikni na: {aktualniMesto}");
            MessageBox.Show($"Klikni na: {aktualniMesto}");
        }
        private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawPoints();
        }

        void DrawPoints()
        {
            OverlayCanvas.Children.Clear();

            foreach (var point in points)
            {
                double x = MapImage.ActualWidth * point.XPercent;
                double y = MapImage.ActualHeight * point.YPercent;

                Button btn = new Button()
                {
                    Content = point.IDMesta,
                    Tag = point
                };

                btn.Click += Btn_Click;

                Canvas.SetLeft(btn, x);
                Canvas.SetTop(btn, y);

                OverlayCanvas.Children.Add(btn);
            }
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            MapPoint point = btn.Tag as MapPoint;
            

            if (point.Name== aktualniMesto)
            {
                MessageBox.Show("Správně!");
                nahoda();
                Skore++;
                
                Kolo++;
            }
            else
            {
                MessageBox.Show($"Špatně! Správná odpověď je: {aktualniMesto}");
                Kolo++;
                
            }
            

        }
        private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(MapImage);

            double xPercent = pos.X / MapImage.ActualWidth;
            double yPercent = pos.Y / MapImage.ActualHeight;
            MessageBox.Show($"{xPercent:F4} , {yPercent:F4}");
        }

        
    }
}
