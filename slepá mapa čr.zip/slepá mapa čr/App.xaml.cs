﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace slepá_mapa_čr
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
