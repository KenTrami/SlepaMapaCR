﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace slepá_mapa_čr
{
    internal class MapPoint
    {
        public string Name { get; set; }
        public double XPercent { get; set; }
        public double YPercent { get; set; }
        public string IDMesta { get; set; }
    }
}
