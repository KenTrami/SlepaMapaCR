﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace slepá_mapa_čr
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<MapPoint> points = new List<MapPoint>()
        {
            new MapPoint{Name= "Praha", XPercent = 0.38, YPercent = 0.38,IDMesta="Město1"},
            new MapPoint{Name= "Brno", XPercent=0.6938, YPercent=0.7105,IDMesta="Město2" },
            new MapPoint{Name= "Pardubice", XPercent=0.5614, YPercent=0.4, IDMesta="Město3" }
        };
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            this.DataContext = this;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DrawPoints();
            nahoda();
        }

        private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawPoints();
        }

        void DrawPoints()
        {
            OverlayCanvas.Children.Clear();

            foreach (var point in points)
            {
                double x = MapImage.ActualWidth * point.XPercent;
                double y = MapImage.ActualHeight * point.YPercent;

                Button btn = new Button()
                {
                    Content = point.IDMesta,
                    Tag = point
                };

                btn.Click += Btn_Click;

                Canvas.SetLeft(btn, x);
                Canvas.SetTop(btn, y);

                OverlayCanvas.Children.Add(btn);
            }
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            MapPoint point = btn.Tag as MapPoint;
            MessageBox.Show(point.Name);
            

        }
        private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(MapImage);

            double xPercent = pos.X / MapImage.ActualWidth;
            double yPercent = pos.Y / MapImage.ActualHeight;

            MessageBox.Show($"{xPercent:F4} , {yPercent:F4}");
        }

        public void nahoda()
        {
            
            Random rand = new Random();
            string NameFinal = points[rand.Next(points.Count)].Name;
            Console.WriteLine($"Klikni na: {NameFinal}");
            //MessageBox.Show($"Klikni na: {NameFinal}");
            if (Name== NameFinal)
            {
                MessageBox.Show("Správně!");
            }
            else
            {
                MessageBox.Show("Špatně, zkus to znovu.");
            }

        }
    }
}
